# Academia Vital Ativa

Site institucional da Academia Vital Ativa, desenvolvido como projeto final da disciplina de Desenvolvimento Web.

## Funcionalidades

- Página inicial com apresentação da academia
- Página de planos com sistema de filtro
- Página institucional com equipe e estrutura
- Sistema de matrícula online com validação
- Layout responsivo
- Integração com API para armazenamento de dados

## Tecnologias Utilizadas

- HTML5
- CSS3
- JavaScript
- JSON Server (API)

## Como Executar

1. Clone o repositório
2. Instale as dependências: `npm install`
3. Inicie o servidor: `json-server --watch db.json`
4. Abra o arquivo `index.html` no navegador

## Autores

- [Seu Nome]
- [Nome do Colega 1]
- [Nome do Colega 2]
- [Nome do Colega 3]
- [Nome do Colega 4] 